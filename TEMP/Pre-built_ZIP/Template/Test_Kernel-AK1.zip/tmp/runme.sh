#!/sbin/sh
#
# Yume Kernel Installer
# Anykernel inline kernel patching script
# Nicklas Van Dam @ XDA
# Yume Project | Codename: Kaori (2019)

# Preparing...
cd /tmp
chmod 0755 unpackbootimg
chmod 0755 mkbootimg

# Unpack the stock kernel...
dd if=/dev/block/bootdevice/by-name/boot of=/tmp/boot.img
./unpackbootimg -i boot.img

# Extracting Yume Kernel...
rm /tmp/boot.img-zImage
cp /tmp/kernel/boot.img-zImage /tmp/boot.img-zImage
rm /tmp/boot.img-dtb
cp /tmp/kernel/boot.img-dtb /tmp/boot.img-dtb

# Define the kernel's attributes for the repacking...
KERNEL_CMDLINE=`cat boot.img-cmdline | sed 's/.*/"&"/'`
KERNEL_BASE=`cat boot.img-base`
KERNEL_PAGESIZE=`cat boot.img-pagesize`
KERNEL_OFFSET=`cat boot.img-kerneloff`
RAMDISK_OFFSET=`cat boot.img-ramdiskoff`
KERNEL_TAGS_OFFSET=`cat boot.img-tagsoff`

# Configuring init.d
# cp /tmp/kernel/99minori /system/etc/init.d/99minori
# chmod 0755 /system/etc/init.d/99minori

# Create boot.img...
echo \#!/sbin/sh > createnewboot.sh
echo "./mkbootimg --kernel boot.img-zImage --ramdisk boot.img-ramdisk.gz --cmdline $KERNEL_CMDLINE --base $KERNEL_BASE --pagesize $KERNEL_PAGESIZE --kernel_offset $KERNEL_OFFSET --ramdisk_offset $RAMDISK_OFFSET --tags_offset $KERNEL_TAGS_OFFSET --dt boot.img-dtb -o newboot.img" >> createnewboot.sh
chmod 0755 createnewboot.sh
./createnewboot.sh

# Flashing new boot.img...
echo Flashing boot.img...
dd if=newboot.img of=/dev/block/bootdevice/by-name/boot

# Remove stock mpdecision
mv /system/vendor/bin/mpdecision /system/vendor/bin/mpdecision.bak
chmod 0666 /system/vendor/bin/mpdecision.bak

exit 0
